/* glitch-lol settings.
   NETLIFY (default): leave as is - the backend is the same site.
   GITHUB PAGES: the backend must still run on Netlify (GitHub Pages cannot run functions).
     api:  your Netlify site, e.g. "https://glitch-lol.netlify.app"
     base: "/" for username.github.io or a custom domain, "/repo-name/" for a project site */
window.GLITCH = {
  api: "",
  base: "/"
};
