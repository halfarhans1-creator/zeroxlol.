// Runs every 5 minutes: keeps website badges in sync with the Discord server
// (joined -> Glitch badge, staff role added/removed -> Staff badge). Needs DISCORD_BOT_TOKEN.
import { getStore } from "@netlify/blobs";
import { syncAll } from "./lib/dc.mjs";

export default async () => {
  if (!process.env.DISCORD_BOT_TOKEN) return new Response("bot not configured", { status: 200 });
  const store = getStore({ name: "glitchbio", consistency: "strong" });
  const r = await syncAll(store, process.env);
  return new Response(JSON.stringify(r), { status: 200 });
};

export const config = { schedule: "*/5 * * * *" };
